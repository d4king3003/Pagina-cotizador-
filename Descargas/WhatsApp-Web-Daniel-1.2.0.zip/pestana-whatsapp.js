"use strict";

const WHATSAPP_ORIGIN = "https://web.whatsapp.com";
const SALESFORCE_ORIGIN = "https://sopesamotos.lightning.force.com";
let lastUsedTabId = null;
let requestQueue = Promise.resolve();

function belongsToWhatsApp(tab) {
  // Check pending navigation first, so a tab navigating away is not reused.
  try { return new URL(tab.pendingUrl || tab.url).origin === WHATSAPP_ORIGIN; }
  catch { return false; }
}

async function showTab(tab) {
  if (Number.isInteger(tab.windowId)) {
    // Navigation has already succeeded even if the window closes before focus.
    try { await chrome.windows.update(tab.windowId, {focused: true}); } catch {}
  }
}

async function openChat(phone, sourceTab) {
  const url = WHATSAPP_ORIGIN + "/send?phone=" + phone;
  const found = (await chrome.tabs.query({url: WHATSAPP_ORIGIN + "/*"}))
    .filter(belongsToWhatsApp);

  // A newly created tab may still be loading and not appear in the URL query.
  // Keeping only its id also prevents duplicate tabs on rapid consecutive clicks.
  if (lastUsedTabId !== null && !found.some(tab => tab.id === lastUsedTabId)) {
    try {
      const pending = await chrome.tabs.get(lastUsedTabId);
      if (belongsToWhatsApp(pending)) found.push(pending);
    } catch {}
  }

  found.sort((a, b) =>
    Number(b.windowId === sourceTab.windowId) - Number(a.windowId === sourceTab.windowId) ||
    Number(b.id === lastUsedTabId) - Number(a.id === lastUsedTabId) ||
    (b.lastAccessed || 0) - (a.lastAccessed || 0) ||
    Number(b.active) - Number(a.active) ||
    a.id - b.id
  );

  for (const tab of found) {
    let updated;
    try {
      const changes = {active: true};
      if ((tab.pendingUrl || tab.url) !== url) changes.url = url;
      updated = await chrome.tabs.update(tab.id, changes);
    } catch (error) {
      // Only a tab that was closed during the operation warrants trying another.
      try { await chrome.tabs.get(tab.id); } catch { continue; }
      throw error;
    }
    lastUsedTabId = updated.id;
    await showTab(updated);
    return {ok: true, reused: true};
  }

  const options = {url, active: true, windowId: sourceTab.windowId};
  const created = await chrome.tabs.create(options);
  lastUsedTabId = created.id;
  await showTab(created);
  return {ok: true, reused: false};
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "DANIEL_OPEN_WHATSAPP") return;
  let allowedOrigin = false;
  try {
    const source = new URL(sender.url);
    // Salesforce, o el archivo del Panel de ventas abierto desde la computadora.
    allowedOrigin = source.origin === SALESFORCE_ORIGIN ||
      (source.protocol === "file:" && decodeURIComponent(source.pathname).includes("Panel-Ventas"));
  } catch {}
  if (sender.id !== chrome.runtime.id || !sender.tab || !allowedOrigin ||
      typeof message.phone !== "string" || !/^[1-9]\d{6,14}$/.test(message.phone)) {
    sendResponse({ok: false});
    return;
  }

  // Serialize requests so two quick clicks cannot both create the first tab.
  requestQueue = requestQueue
    .then(() => openChat(message.phone, sender.tab))
    .then(sendResponse, () => sendResponse({ok: false}));
  return true;
});
