(() => {
  "use strict";

  // Access to Lightning's public value property also handles closed shadow roots.
  // The MAIN world is intentional; this script uses no extension APIs.
  if (window.__danielWhatsappWebInstalled) return;
  window.__danielWhatsappWebInstalled = true;

  function normalizePhone(value) {
    if (value == null) return null;
    let raw = String(value).trim().replace(/^(tel|callto):/i, "");
    try { raw = decodeURIComponent(raw); } catch { return null; }
    raw = raw.split(/[;?]/, 1)[0].trim();
    if (!/^\+?[\d\s().-]+$/.test(raw)) return null;
    const international = raw.startsWith("+") || raw.startsWith("00");
    let digits = raw.replace(/\D/g, "");
    if (digits.startsWith("00")) digits = digits.slice(2);
    if (digits.length === 8 && !international) digits = "503" + digits;
    // Only full international numbers or Salvadoran local numbers are accepted.
    const pattern = international ? /^[1-9]\d{6,14}$/ : /^[1-9]\d{8,14}$/;
    if (!pattern.test(digits)) return null;
    return digits;
  }

  function phoneFromLink(link) {
    const href = (link.getAttribute("href") || "").trim();
    if (/^(tel|callto):/i.test(href)) return normalizePhone(href);
    if (/^whatsapp:\/\/send(?:[/?]|$)/i.test(href)) {
      try { return normalizePhone(new URL(href).searchParams.get("phone")); }
      catch { return null; }
    }
    return null;
  }

  function clickedPhone(event) {
    const path = event.composedPath();
    for (const node of path) {
      if (!(node instanceof Element)) continue;
      if (node.localName === "a") {
        const phone = phoneFromLink(node);
        if (phone) return phone;
      }
      if (["lightning-formatted-phone", "lightning-click-to-dial"].includes(node.localName)) {
        if (node.disabled || node.hasAttribute("disabled")) return null;
        const phone = normalizePhone(node.value ?? node.getAttribute("value"));
        if (phone) return phone;
      }
    }
    return null;
  }

  function openChat(event) {
    if (!event.isTrusted || event.defaultPrevented) return;
    if (event.type === "click" && event.button !== 0) return;
    if (event.type === "auxclick" && event.button !== 1) return;
    const phone = clickedPhone(event);
    if (!phone) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    // The isolated bridge asks the service worker to reuse a WhatsApp tab.
    // No messages are written or sent inside WhatsApp.
    window.dispatchEvent(new CustomEvent("daniel-whatsapp-web-open-v1", {detail: phone}));
  }

  window.addEventListener("click", openChat, true);
  window.addEventListener("auxclick", openChat, true);
})();
