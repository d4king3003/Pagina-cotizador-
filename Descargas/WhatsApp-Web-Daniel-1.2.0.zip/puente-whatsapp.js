(() => {
  "use strict";
  let gestureUntil = -1;

  // Registered before the MAIN-world handler. Each real click authorizes one
  // request; an arbitrary page event cannot start opening chats in the background.
  function rememberGesture(event) {
    if (!event.isTrusted || event.defaultPrevented) return;
    if ((event.type === "click" && event.button === 0) ||
        (event.type === "auxclick" && event.button === 1)) {
      gestureUntil = performance.now() + 500;
    }
  }
  window.addEventListener("click", rememberGesture, true);
  window.addEventListener("auxclick", rememberGesture, true);
  window.addEventListener("daniel-whatsapp-web-open-v1", (event) => {
    if (performance.now() > gestureUntil) return;
    if (typeof event.detail !== "string" || !/^[1-9]\d{6,14}$/.test(event.detail)) return;
    gestureUntil = -1;
    chrome.runtime.sendMessage({type: "DANIEL_OPEN_WHATSAPP", phone: event.detail})
      .then((response) => {
        if (!response?.ok) throw new Error("No se pudo abrir la pestaña.");
      })
      .catch(() => {
        window.alert("No se pudo abrir WhatsApp Web. Recargá la extensión en chrome://extensions y después recargá esta página con F5.");
      });
  }, true);
})();
